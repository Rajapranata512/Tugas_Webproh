<?php $__env->startSection('content'); ?>
Home Page
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProjectWebProg\resources\views/homePage.blade.php ENDPATH**/ ?>