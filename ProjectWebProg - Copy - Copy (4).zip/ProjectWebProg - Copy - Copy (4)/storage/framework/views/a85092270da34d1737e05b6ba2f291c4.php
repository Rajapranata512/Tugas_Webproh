<?php $__env->startSection('content'); ?>
<div class="container-fluid vh-100 d-flex justify-content-center align-items-center" style="background-image: url('/images/background.jpg');
background-size: cover;
background-repeat: no-repeat;
background-position: center;">
    <?php if(Auth::check()): ?>
        <div class="profile-section">
            <div class="card-body" style="background-color: white; color: white; border-radius: 15px; padding: 20px;">
                <img src="<?php echo e(asset('images/user.jpg')); ?>" alt="Foodies" class="logo-image">
                <h3 style="color: black">Selamat datang, <?php echo e(Auth::user()->name); ?></h3>
                <p style="color: black">Email: <?php echo e(Auth::user()->email); ?></p>
                <div class="d-flex justify-content-center align-items-center">
                    <form action="<?php echo e(route('logout')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger">Logout</button>
                    </form>
                </div>
            </div>
        </div>
    <?php else: ?>
        <a href="<?php echo e(route('register')); ?>" class="btn btn-primary">Register</a>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProjectWebProg - Copy\resources\views/profile.blade.php ENDPATH**/ ?>