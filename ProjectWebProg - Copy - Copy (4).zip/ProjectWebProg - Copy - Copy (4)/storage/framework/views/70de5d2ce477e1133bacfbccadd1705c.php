<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/layout.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Foodies</title>
</head>
<body>
    <div class="wrapper">
        <header class="main-header">
            <div class="container d-flex justify-content-between align-items-center">
                <div class="logo-container">
                    <img src="<?php echo e(asset('images/logo.jpg')); ?>" alt="Foodies" class="logo-image">
                    <h1 class="site-title">Foodies</h1>
                </div>
                <nav class="nav-menu">
                    <ul>
                        <li><a href="<?php echo e(route('foodies.home')); ?>">Beranda</a></li>
                        <li><a href="<?php echo e(route('add.recipe')); ?>">Tambah Resep</a></li>
                        <li><a href="<?php echo e(route('allRecipes')); ?>">Semua Resep</a></li>
                        <?php if(Auth::check()): ?>
                            <li><a href="<?php echo e(route('profile')); ?>">Profil</a></li>
                        <?php else: ?>
                            <li><a href="<?php echo e(route('register')); ?>">Daftar</a></li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
        </header>
        <body>
            <div class="row">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </body>

    </div>
    <footer class="footer">
        <p>&copy; Project Website Programming</p>
    </footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ProjectWebProg - Copy\resources\views/layout.blade.php ENDPATH**/ ?>