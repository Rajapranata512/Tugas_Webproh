<?php $__env->startSection('content'); ?>



    <div style="max-width: 800px; margin: 0 auto; padding: 20px; background-color: #fff; box-shadow: 2px 2px 8px rgba(0, 0, 0, 0.1); border-radius: 8px;">
        <h1 style="text-align: center; margin: 20px 0;"><?php echo e($recipe->name); ?></h1>
        <img
            src="<?php echo e(asset('images/' . strtolower(str_replace(' ', '_', $recipe->name)) . '.jpg')); ?>"
            alt="<?php echo e($recipe->name); ?>"
            style="width: 100%; height: 300px; object-fit: cover; border-radius: 8px; margin-bottom: 20px;"
        >
        <h2 style="color: #333;">Description</h2>
        <p style="font-size: 16px; color: #555;"><?php echo e($recipe->description); ?></p>

        <h2 style="color: #333;">Ingredients</h2>
        <ul style="font-size: 16px; color: #555;">
            <?php $__currentLoopData = $recipe->ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($ingredient->name); ?> - <?php echo e($ingredient->quantity); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <h2 style="color: #333;">Steps</h2>
        <ol style="font-size: 16px; color: #555;">
            <?php $__currentLoopData = $recipe->steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($step->description); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>

        <h2 style="color: #333;">Equipments</h2>
        <ul style="font-size: 16px; color: #555;">
            <?php $__currentLoopData = $recipe->equipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($equipment->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <a href="<?php echo e(route('allRecipes')); ?>" class="btn btn-primary">Back</a>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProjectWebProg - Copy\resources\views/recipesDetails.blade.php ENDPATH**/ ?>