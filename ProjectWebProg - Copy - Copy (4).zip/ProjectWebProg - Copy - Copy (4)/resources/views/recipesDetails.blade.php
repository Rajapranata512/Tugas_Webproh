@extends('layout')

@section('content')



    <div style="max-width: 800px; margin: 0 auto; padding: 20px; background-color: #fff; box-shadow: 2px 2px 8px rgba(0, 0, 0, 0.1); border-radius: 8px;">
        <h1 style="text-align: center; margin: 20px 0;">{{ $recipe->name }}</h1>
        <img
            src="{{ asset('images/' . strtolower(str_replace(' ', '_', $recipe->name)) . '.jpg') }}"
            alt="{{ $recipe->name }}"
            style="width: 100%; height: 300px; object-fit: cover; border-radius: 8px; margin-bottom: 20px;"
        >
        <h2 style="color: #333;">Description</h2>
        <p style="font-size: 16px; color: #555;">{{ $recipe->description }}</p>

        <h2 style="color: #333;">Ingredients</h2>
        <ul style="font-size: 16px; color: #555;">
            @foreach ($recipe->ingredients as $ingredient)
                <li>{{ $ingredient->name }} - {{ $ingredient->quantity }}</li>
            @endforeach
        </ul>

        <h2 style="color: #333;">Steps</h2>
        <ol style="font-size: 16px; color: #555;">
            @foreach ($recipe->steps as $step)
                <li>{{ $step->description }}</li>
            @endforeach
        </ol>

        <h2 style="color: #333;">Equipments</h2>
        <ul style="font-size: 16px; color: #555;">
            @foreach ($recipe->equipments as $equipment)
                <li>{{ $equipment->name }}</li>
            @endforeach
        </ul>
        <a href="{{ route('allRecipes')}}" class="btn btn-primary">Back</a>
    </div>

@endsection
