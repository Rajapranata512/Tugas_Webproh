<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Recipe;

class RecipeController extends Controller
{
    //
    public function homePage(){

        return view('homePage');
    }

    public function addRecipe(){
        $recipes = Recipe::all();
        $cuisines = Recipe::distinct()->pluck('cuisine');
        $difficulties = Recipe::distinct()->pluck('difficulty');
        $courses = Recipe::distinct()->pluck('meal_course');
        return view('addRecipe',
        ['recipes'=>$recipes,
                'cuisines'=>$cuisines,
                'difficulties'=>$difficulties,
                'courses'=>$courses
                ]);
    }

    public function storeRecipe(Request $request){
        $validated = $request->validate([
            'name' => 'required|string|max:100',
            'cuisine' => 'required|in:Western,Asian,Middle Eastern,African',
            'description' => 'required|string',
            'meal_course' => 'required|in:Dessert,Main Course,Appetizer',
            'time' => 'required|integer|min:1',
            'origin' => 'required|string|max:100',
            'difficulty' => 'required|in:Easy,Medium,Hard',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $recipe = new Recipe();
        $recipe->name = $validated['name'];
        $recipe->cuisine = $validated['cuisine'];
        $recipe->description = $validated['description'];
        $recipe->meal_course = $validated['meal_course'];
        $recipe->time = $validated['time'];
        $recipe->origin = $validated['origin'];
        $recipe->difficulty = $validated['difficulty'];
        $recipe->image = $request->file('image')->store('images', 'public');
        $recipe->save();

        return redirect()->back()->with('success', 'Recipe berhasil ditambahkan!');
    }
    public function allRecipes(Request $request)
    {
        $query = Recipe::with(['steps', 'equipments', 'ingredients']);

        if ($request->filled('cuisine')) {
            $query->where('cuisine', $request->input('cuisine'));
        }

        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->input('search') . '%');
        }

        $recipes = $query->paginate(6);

        return view('allRecipes', compact('recipes'));
    }

    public function details($id)
    {
        $recipe = Recipe::with(['steps', 'equipments', 'ingredients'])->findOrFail($id);

        return view('recipesDetails', compact('recipe'));
    }
}
