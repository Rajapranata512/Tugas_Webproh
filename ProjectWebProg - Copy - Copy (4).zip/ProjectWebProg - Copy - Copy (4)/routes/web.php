<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RecipeController;
use App\Http\Controllers\AuthController;

//Home Page
Route::get('/', [RecipeController::class, 'homePage'])->name('foodies.home');

//Add Recipe
Route::get('/addRecipe', [RecipeController::class, 'addRecipe'])->name('add.recipe');
Route::post('/addRecipe/Store', [RecipeController::class, 'storeRecipe'])->name('store.recipe');

//Login & Register
Route::get('/register', [AuthController::class, 'register'])->name('register');
Route::post('doregister', [AuthController::class,'doregister'])->name('doregister');
Route::get('/profile', [Authcontroller::class, 'profile'])->name('profile');
Route::post('logout', [AuthController::class, 'logout'])->name('logout');
Route::get('/login', [AuthController::class, 'login'])->name('login');
Route::post('/login', [AuthController::class, 'processLogin'])->name('login.process');

// All recipes
Route::get('/allRecipes', [RecipeController::class, 'allRecipes'])->name('allRecipes');
Route::get('/recipes/{id}', [RecipeController::class, 'details'])->name('recipe.details');
